import json
import hashlib
import random
host = input('请输入绑定的域名或IP:')
tcpList = []
for i in range(10000,10100):
    md5_obj = hashlib.md5()
    md5_obj.update(str(random.random()).encode())
    md5 = md5_obj.hexdigest().lower()
    tcpList.append({
        "master":"0.0.0.0:"+str(i),
        "customer":"0.0.0.0:"+str(i+100),
        "secretkey":md5[:10]
    })
writeJson = {
    "http":{
        "to_master":"0.0.0.0:10001",
        "customer":"0.0.0.0:800",
        "host":[
            {
                "domain":host
            }
        ]
    },

    "tcp":tcpList
}
with open('config.json','w') as f:
    f.write(json.dumps(writeJson))