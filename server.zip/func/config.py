host = '192.168.1.94' #本机IP,也可填写域名,不要带http的前缀和最后面的/
username = 'admin'    #管理页面账号
password = 'wenrui'   #管理页面密码
port = 7440             #本服务运行的端口,如修改此项,记得同时修改服务器管理程序的配置--NATPenetrationPort
                      #同时,服务端将会视连接数量,使用10000-20000端口,请开放此段端口